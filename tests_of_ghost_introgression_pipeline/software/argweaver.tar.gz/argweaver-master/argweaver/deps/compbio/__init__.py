"""

    The CompBio python module

    Various utilities for computational biology.

"""
