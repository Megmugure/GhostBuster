#ifndef ARGWEAVER_FS_H
#define ARGWEAVER_FS_H

bool makedirs(const char *path, mode_t mode=0777);

#endif
