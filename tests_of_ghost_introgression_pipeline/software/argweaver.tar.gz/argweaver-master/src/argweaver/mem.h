/*=============================================================================

  Matt Rasmussen

  Memory functions

=============================================================================*/

#ifndef ARGWEAVER_MEM_H
#define ARGWEAVER_MEM_H

long get_max_memory_usage();

#endif
