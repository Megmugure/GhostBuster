
extern "C" {

double *expm11 ( int n, double a[] );
double *expm2 ( int n, double a[] );
double *expm3 ( int n, double a[] );

}
