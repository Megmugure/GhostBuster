(function () {
    window.arghost = "{{ host }}";

    // import default argtracks
    mashome.importScripts(
        [window.arghost + "/static/js/argtrack.js"]);
})();
